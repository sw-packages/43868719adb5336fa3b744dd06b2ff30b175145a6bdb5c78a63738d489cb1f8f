
#ifndef _FPFIXUP_H_INCLUDED
#define _FPFIXUP_H_INCLUDED

extern void AddFloatingPointEmulationFixup( struct code_info * );

#endif

