
#ifndef _MACROLIB_H_
#define _MACROLIB_H_

void InitAutoMacros64();
void InitAutoMacros32();

#endif