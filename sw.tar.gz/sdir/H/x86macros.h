#if !(NOX86MACROLIB)
void Addx86defs(void);
void x86CreateMacroLibCases(void);
void Initx86AutoMacros64(void);
#endif