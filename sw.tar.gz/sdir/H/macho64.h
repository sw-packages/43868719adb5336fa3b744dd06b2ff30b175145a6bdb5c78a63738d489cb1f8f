
/* prototypes of functions defined in macho64.c */

#ifndef _MACHO64_H_INCLUDED_
#define _MACHO64_H_INCLUDED_

void     macho_init(struct module_info *);

#endif // _MACHO64_H_INCLUDED_
