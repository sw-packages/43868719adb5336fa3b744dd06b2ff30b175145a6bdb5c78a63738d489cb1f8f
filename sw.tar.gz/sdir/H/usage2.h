"   UASM [options] asm-file [options] [asm-file] ... [@env_var]\n\n\0"
"Options: \0"
"\n"